import './App.css';
import Translate from './components/Translate';

function App() {
  return (
    <div>
      <Translate/>
    </div>
  );
}

export default App;
